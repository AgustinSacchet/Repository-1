from setuptools import setup

setup(
    name="paquete_clientes",
    version=1.0,
    descripcion="Paquete de Agustin",
    author="Sacchet Agustin",
    author_email="agustin9393@gmail.com",
    
    packages=["paquete"],
)